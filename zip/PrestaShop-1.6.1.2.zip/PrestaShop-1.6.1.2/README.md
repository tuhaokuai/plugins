# 图好快 加速插件 


1. 下载 `SmartyCustom.php` 并放到 `PrestaShop-1.6.1.2` 项目 `override/classes` 目录下

2. 删除 `cache/class_index.php` 



