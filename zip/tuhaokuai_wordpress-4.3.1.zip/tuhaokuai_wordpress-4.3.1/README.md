# 图好快  wordpress 4.3.1

## 使用方法：

1. 下载`tuhaokuai_wordpress-4.3.1`到您的网站`wp-content/plugins`下并改名为`tuhaokuai`

2. 进入后台->插件 启用 图好快-全站加速

 

功能说明：

所有css,js,img都会走图好快全站加速。


