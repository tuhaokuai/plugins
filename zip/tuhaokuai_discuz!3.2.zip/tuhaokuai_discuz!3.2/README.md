# 图好快  Discuz! X3.2  简体中文 utf8

##使用方法：

1. 下载`tuhaokuai_discuz!3.2`到您的网站`source/plugins`下并改名为`tuhaokuai`

2. 进入后台->应用->启用插件 



功能说明：

目前仅对帖子中的图片提供加速功能,以及发帖回帖人的头像为静态地址(如/data...jpg png gif，不支持以.php生成的地址)


